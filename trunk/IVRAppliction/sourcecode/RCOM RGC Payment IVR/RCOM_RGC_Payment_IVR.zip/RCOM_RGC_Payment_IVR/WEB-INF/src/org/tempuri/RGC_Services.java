/**
 * RGC_Services.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public interface RGC_Services extends javax.xml.rpc.Service {
    public java.lang.String getRGC_ServicesSoapAddress();

    public org.tempuri.RGC_ServicesSoap getRGC_ServicesSoap() throws javax.xml.rpc.ServiceException;

    public org.tempuri.RGC_ServicesSoap getRGC_ServicesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
